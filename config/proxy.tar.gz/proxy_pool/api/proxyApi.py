# -*- coding: utf-8 -*-
# !/usr/bin/env python
"""
-------------------------------------------------
   File Name:     ProxyApi.py
   Description :   WebApi
   Author :       JHao
   date:          2016/12/4
-------------------------------------------------
   Change Activity:
                   2016/12/04: WebApi
                   2019/08/14: 集成Gunicorn启动方式
                   2020/06/23: 新增pop接口
                   2022/07/21: 更新count接口
-------------------------------------------------
"""
__author__ = "JHao"

import platform
from werkzeug.wrappers import Response
from flask import Flask, jsonify, request

from util.six import iteritems
from helper.proxy import Proxy
from handler.proxyHandler import ProxyHandler
from handler.configHandler import ConfigHandler

app = Flask(__name__)
conf = ConfigHandler()
proxy_handler = ProxyHandler()


class JsonResponse(Response):
    """
    重写Response的force_type方法,使返回的数据统一为json格式
    """

    @classmethod
    def force_type(cls, response, environ=None):
        if isinstance(response, (dict, list)):
            response = jsonify(response)

        return super(JsonResponse, cls).force_type(response, environ)


# 这段代码通过定义一个新的响应类 JsonResponse 并将其设置为 Flask 应用的默认响应类,实现了自动将字典或列表类型的响应体转换为 JSON 格式的功能,简化了返回 JSON 响应的过程.
app.response_class = JsonResponse

api_list = [
    {"url": "/get", "params": "type: ''https'|''", "desc": "get a proxy"},
    {"url": "/pop", "params": "", "desc": "get and delete a proxy"},
    {
        "url": "/delete",
        "params": "proxy: 'e.g. 127.0.0.1:8080'",
        "desc": "delete an unable proxy",
    },
    {
        "url": "/all",
        "params": "type: ''https'|''",
        "desc": "get all proxy from proxy pool",
    },
    {"url": "/count", "params": "", "desc": "return proxy count"},
    # 'refresh': 'refresh proxy pool',
]


@app.route("/")
def index():
    return {"url": api_list}


@app.route("/get/")
def get():
    https = request.args.get("type", "").lower() == "https"  # bool值
    proxy = proxy_handler.get(https)
    return proxy.to_dict if proxy else {"code": 0, "src": "no proxy"}


@app.route("/pop/")
def pop():
    https = request.args.get("type", "").lower() == "https"
    proxy = proxy_handler.pop(https)
    return proxy.to_dict if proxy else {"code": 0, "src": "no proxy"}


@app.route("/refresh/")
def refresh():
    # TODO refresh会有守护程序定时执行,由api直接调用性能较差,暂不使用
    return "success"


@app.route("/all/")
def getAll():
    https = request.args.get("type", "").lower() == "https"
    proxies = proxy_handler.getAll(https)
    return jsonify([_.to_dict for _ in proxies])


@app.route("/delete/", methods=["GET"])
def delete():
    proxy = request.args.get("proxy")
    status = proxy_handler.delete(Proxy(proxy))
    return {"code": 0, "src": status}


@app.route("/count/")
def getCount():
    proxies = proxy_handler.getAll()
    http_type_dict = {}
    source_dict = {}
    for proxy in proxies:
        http_type = "https" if proxy.https else "http"
        http_type_dict[http_type] = http_type_dict.get(http_type, 0) + 1
        for source in proxy.source.split("/"):
            source_dict[source] = source_dict.get(source, 0) + 1
    return {"http_type": http_type_dict, "source": source_dict, "count": len(proxies)}


def runFlask():
    """在runFlask函数中,如果检测到操作系统不是Windows,会创建一个StandaloneApplication实例,并传入Flask应用实例app和一个配置字典_options.
    这个配置字典包含了Gunicorn服务器的一些配置项,如绑定的地址和端口、工作进程数等.然后调用StandaloneApplication实例的run方法来启动Gunicorn服务器
    """
    if platform.system() == "Windows":
        app.run(host=conf.serverHost, port=conf.serverPort)
    else:
        import gunicorn.app.base

        class StandaloneApplication(gunicorn.app.base.BaseApplication):
            """当前类用于配置和启动Gunicorn服务器 构造函数接收Flask应用实例和一个可选的配置字典"""

            def __init__(self, app, options=None):
                self.options = options or {}
                self.application = app
                super().__init__()

            def load_config(self):
                """这个方法用于加载Gunicorn服务器的配置.它遍历options字典,将有效的配置项设置到Gunicorn配置中."""
                _config = dict(
                    [
                        (key, value)
                        for key, value in iteritems(self.options)
                        if key in self.cfg.settings and value is not None
                    ]
                )
                for key, value in iteritems(
                    _config
                ):  # 这里的遍历字典是Python2中的写法 类似my_dict.items()
                    self.cfg.set(key.lower(), value)

            def load(self):
                # 这个方法返回Flask应用实例,供Gunicorn服务器使用.
                return self.application

        _options = {
            # 这段代码定义了Gunicorn服务器的配置,包括绑定的地址和端口、工作进程数、访问日志的输出位置和格式.
            "bind": "%s:%s" % (conf.serverHost, conf.serverPort),
            "workers": 4,
            "accesslog": "-",  # log to stdout
            "access_log_format": '%(h)s %(l)s %(t)s "%(r)s" %(s)s "%(a)s"',
        }
        # 这行代码创建了一个StandaloneApplication实例,并传入Flask应用和配置字典,然后调用run方法启动Gunicorn服务器.
        StandaloneApplication(app, _options).run()


if __name__ == "__main__":
    runFlask()

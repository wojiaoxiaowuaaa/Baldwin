# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name:     singleton
   Description :
   Author :        JHao
   date:          2016/12/3
-------------------------------------------------
   Change Activity:
                   2016/12/3:
-------------------------------------------------
"""


class Singleton(type):
    """
    Singleton Metaclass
    类变量_inst是一个字典,用于存储已经创建的实例.键是类(cls),值是该类的实例.这确保了每个类只能有一个实例.
    __call__方法是当实例被调用时执行的方法.在这里,它被用来拦截类的实例化过程.

    """

    _inst = {}

    def __call__(cls, *args, **kwargs):
        if cls not in cls._inst:
            cls._inst[cls] = super(Singleton, cls).__call__(*args)
        return cls._inst[cls]


class MyClass(metaclass=Singleton):
    """
    测试单例类的使用
    """

    def __init__(self, data):
        self.data = data


# 创建两个MyClass的实例
instance1 = MyClass('data2')
instance2 = MyClass('data1')

# 检查这两个实例是否相同
# print(instance1 is instance2)  # 输出: True

# 检查实例的data属性
# print(instance1.data)  # 输出: 'data1'
# print(instance2.data)  # 输出: 'data1'

# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name:     lazyProperty
   Description :
   Author :        JHao
   date:          2016/12/3
-------------------------------------------------
   Change Activity:
                   2016/12/3:
-------------------------------------------------
"""


class LazyProperty(object):
    """
    这段代码定义了一个名为 LazyProperty 的类,其主要作用是作为一个装饰器,用于实现延迟加载属性的功能.
    这意味着,被 LazyProperty 装饰的属性在第一次被访问时才会计算其值,并将结果缓存起来,之后的访问直接返回之前缓存的值,而不需要再次计算.这种机制对于提高性能特别有用,尤其是在计算或获取属性值代价较大时.
    """

    def __init__(self, func):
        # func是被装饰的方法. self.func 用于存储这个方法,以便后续使用.
        self.func = func

    def __get__(self, instance, owner):
        # instance:包含描述符的类的实例.当通过实例访问属性时,这个参数就是那个实例.如果描述符是直接从类访问的(而不是通过实例),则这个参数是 None.
        # owner:包含描述符的类.这个参数是描述符所属的类,而不是实例.这在处理类属性时非常有用.
        if instance is None:
            return self
        else:
            value = self.func(instance)
            # 通过 self.func 计算得到的属性值 value,赋值给 instance 对象的 self.func.__name__ 属性.这样,当属性被再次访问时,就可以直接返回已经缓存的值,而不需要重新计算,从而提高了程序的性能.
            setattr(instance, self.func.__name__, value)
            return value


class Person:
    """
    测试装饰器方法
    """

    def __init__(self, name, age):
        self.name = name
        self.age = age
        self._expensive_computation_done = False

    @LazyProperty
    def expensive_computation(self):
        if not self._expensive_computation_done:
            print("进行了昂贵的计算...")
            self._expensive_computation_done = True
        return "计算结果"


# person = Person("张三", 30)
# print(person.expensive_computation)  # 第一次访问,将进行计算
# print(person.expensive_computation)  # 第二次访问,直接返回缓存的结果,不再进行计算

# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name:      test.py
   Description :   test file for proxy pool
   Author :        jHao
   date:          2017/3/7
-------------------------------------------------
   auther blog:     https://www.spiderpy.cn/blog/detail/13/
-------------------------------------------------
"""
__author__ = "JHao"

from test import testProxyValidator
from test import testConfigHandler
from test import testLogHandler
from test import testDbClient

if __name__ == "__main__":
    print("ConfigHandler:")
    testConfigHandler.testConfig()

    print("LogHandler:")
    testLogHandler.testLogHandler()

    print("DbClient:")
    testDbClient.testDbClient()

    print("ProxyValidator:")
    testProxyValidator.testProxyValidator()

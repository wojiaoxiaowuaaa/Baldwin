# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name:     testProxyClass
   Description :
   Author :        JHao
   date:          2019/8/8
-------------------------------------------------
   Change Activity:
                   2019/8/8:
-------------------------------------------------
"""
import json
from helper.proxy import Proxy


def testProxyClass():
    proxy = Proxy("127.0.0.1:8080")

    print(proxy.to_json)

    proxy._source = "test"

    proxy_str = json.dumps(proxy.to_dict, ensure_ascii=False)

    print(proxy_str)  # {"proxy": "127.0.0.1:8080", "https": false, "fail_count": 0, "region": "", "anonymous": "", "source": "t/e/s/t", "check_count": 0, "last_status": "", "last_time": ""}

    print(Proxy.createFromJson(proxy_str).to_dict)


if __name__ == "__main__":
    testProxyClass()

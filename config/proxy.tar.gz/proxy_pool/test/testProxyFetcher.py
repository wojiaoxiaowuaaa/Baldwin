# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name:     testProxyFetcher
   Description :
   Author :        JHao
   date:          2020/6/23
-------------------------------------------------
   Change Activity:
                   2020/6/23:
-------------------------------------------------
"""
from fetcher.proxyFetcher import ProxyFetcher
from handler.configHandler import ConfigHandler
from loguru import logger


def testProxyFetcher():
    conf = ConfigHandler()
    proxy_getter_functions = conf.fetchers
    proxy_counter = {_: 0 for _ in proxy_getter_functions}
    for proxyGetter in proxy_getter_functions:
        for proxy in getattr(ProxyFetcher, proxyGetter.strip())():
            # 遍历生成器获取代理信息
            if proxy:
                print(
                    # freeProxy03: fetch proxy 60.174.0.143:8089
                    "{func}: fetch proxy {proxy}".format(func=proxyGetter, proxy=proxy)
                )
                proxy_counter[proxyGetter] = proxy_counter.get(proxyGetter) + 1
    # logger.info(proxy_counter)   {'freeProxy02': 0, 'freeProxy03': 20, 'freeProxy04': 0, 'freeProxy05': 0, 'freeProxy06': 0, 'freeProxy07': 30, 'freeProxy08': 0, 'freeProxy09': 0, 'freeProxy10': 0, 'freeProxy11': 0}


if __name__ == "__main__":
    testProxyFetcher()

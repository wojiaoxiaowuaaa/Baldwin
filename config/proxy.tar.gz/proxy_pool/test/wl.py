import sys
sys.path.insert(0, '/Users/wl/proxy_pool/')
import os
import requests
import redis
import time
import json
import random
import site
from pathlib import Path
from handler.logHandler import LogHandler
import setting
import threading
log = LogHandler('wl')


def get_proxy():
    return requests.get("http://127.0.0.1:5010/get/").json()


def delete_proxy(proxy):
    requests.get("http://127.0.0.1:5010/delete/?proxy={}".format(proxy))


def get_html():
    retry_count = 5
    proxy = get_proxy().get("proxy")
    # print(proxy)  # 198.44.255.3:80
    while retry_count > 0:
        try:
            # 使用代理访问
            html = requests.get(
                "http://www.baidu.com", proxies={"http": "http://{}".format(proxy)}
            )
            # print(html.text)
            return html
        except Exception:
            retry_count -= 1
    # 删除代理池中代理
    delete_proxy(proxy)
    return None


def get_data():
    r = redis.Redis(host="127.0.0.1", port=6379, db=0)

    all_dic = r.hgetall("use_proxy")

    # for key in all_dic: print(type(all_dic[key]))  # <class 'bytes'>

    all_dic = {k.decode("utf-8"): v.decode("utf-8") for k, v in all_dic.items()}

    # print(all_dic)

    # print(json.dumps(all_dic, ensure_ascii=False,  indent=4))

    # with open("use_proxy.json", "w") as f:
    #     json.dump(all_dic, f, ensure_ascii=False, indent=4)

    # proxy = {"ip port": random.choice(list(all_dic.keys()))}
    #
    # print(proxy)

    # k, v = list(all_dic.items())[0]
    # var = {k: v}
    # print(var)


if __name__ == '__main__':
    ...
    # print(get_data())

    # print(get_proxy())

    # for i in sys.path: print(i)

    # for i in site.getsitepackages(): print(i)

    # print(Path("../../.zshrc").read_text())


# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name:     fetchScheduler
   Description :
   Author :        JHao
   date:          2019/8/6
-------------------------------------------------
   Change Activity:
                   2021/11/18: 多线程采集
-------------------------------------------------
脚本的整个流程:
1. 创建多个_ThreadFetcher线程,每个线程负责从一个特定的源抓取代理.
2. 线程启动后,执行各自的fetcher方法,将抓取到的代理信息存入proxy_dict.
3. 主线程等待所有子线程完成.
4. 对proxy_dict中的代理进行初步验证,返回有效的代理信息.
-------------------------------------------------
"""
from threading import Thread
from helper.proxy import Proxy
from helper.check import DoValidator
from handler.logHandler import LogHandler
from handler.proxyHandler import ProxyHandler
from fetcher.proxyFetcher import ProxyFetcher
from handler.configHandler import ConfigHandler


class _ThreadFetcher(Thread):
    """多线程采集器
    1. 通过继承 Thread 类,可以创建自定义线程类.
    2. 重写 run 方法:在自定义线程类中,重写 run 方法来定义线程在启动后执行的代码.
    3. 启动线程:通过调用 start 方法启动线程,这会自动调用 run 方法."""

    def __init__(self, fetch_source, proxy_dict):
        Thread.__init__(self)
        self.fetch_source = fetch_source  # 爬虫中的代理来源如 freeProxy01
        self.proxy_dict = proxy_dict
        self.fetcher = getattr(ProxyFetcher, fetch_source, None)
        self.log = LogHandler("fetcher")
        self.conf = ConfigHandler()
        self.proxy_handler = ProxyHandler()

    def run(self):
        """多线程循环调用run方法 执行的次数与配置文件中PROXY_FETCHER列表长度相关"""
        self.log.info("ProxyFetch - {func}: start".format(func=self.fetch_source))
        try:
            for proxy in self.fetcher():
                self.log.info("ProxyFetch - %s: %s ok" % (self.fetch_source, proxy.ljust(23)))  # ProxyFetch - freeProxy03: 116.63.160.98:8899      ok
                proxy = proxy.strip()
                if proxy in self.proxy_dict:
                    self.proxy_dict[proxy].add_source(self.fetch_source)  # 字典self.proxy_dict用于存储代理信息,其中字典的键是代理的IP和端口(即proxy),值是proxy.py中Proxy类的实例.  self.proxy_dict[proxy]是一个实例对象他有一个add_source方法
                else:
                    self.proxy_dict[proxy] = Proxy(proxy, source=self.fetch_source)  # 构造完整的代理信息数据  字典的键proxy为IP&PORT形式 字典的值Proxy的实例是完整的代理信息
        except Exception as e:
            self.log.error("ProxyFetch - {func}: error".format(func=self.fetch_source))
            self.log.error(str(e))


class Fetcher(object):
    name = "fetcher"

    def __init__(self):
        self.log = LogHandler(self.name)
        self.conf = ConfigHandler()

    def run(self):
        """
        Fetcher 类的 run 方法则显式地返回了一个生成器.这个生成器会在所有线程完成代理抓取和初步验证后,遍历 proxy_dict 中的每个代理,对它们进行预验证(preValidator),并将验证通过的代理信息通过 yield 关键字逐个返回.这个生成器可以迭代出所有有效且经过初步验证的代理信息
        _ThreadFetcher.run() 不返回任何值,它的效果体现在更新了 proxy_dict.
        Fetcher.run() 返回一个生成器.当你在代码中调用 Fetcher().run() 并迭代其结果时,你会得到一个包含所有有效代理的序列,每个代理都是 Proxy 类的实例.

        proxy_dict 是一个字典，用于存储代理信息。字典的键是代理的 IP 和端口（即 proxy），格式为 "IP:PORT"。字典的值是 Proxy 类的实例，这些实例包含了关于代理的详细信息，如是否支持 HTTPS、失败次数、地理位置、匿名度、来源、检测次数、最后一次检测的状态和时间等。
        作用：proxy_dict 用于在多线程采集过程中收集和存储从不同源抓取到的代理信息。每个线程负责从一个特定的源抓取代理，并将抓取到的代理信息添加到 proxy_dict 中。如果某个代理已经存在于 proxy_dict 中，则更新其来源信息；如果不存在，则创建一个新的 Proxy 实例并添加到字典中。

        thread_list 是一个列表，用于存储 _ThreadFetcher 类的实例。每个 _ThreadFetcher 实例都是一个线程，负责从一个特定的源抓取代理信息。
        作用：thread_list 用于管理和控制所有的抓取线程。脚本首先根据配置文件中的 fetchers 列表创建多个 _ThreadFetcher 线程，并将这些线程实例添加到 thread_list 中。然后，脚本启动列表中的每个线程，并等待所有线程完成。这样，脚本可以并行地从多个源抓取代理信息，提高抓取效率。

        总结来说，proxy_dict 和 thread_list 分别用于存储'抓取到的代理信息'和'管理抓取线程'.通过这两个数据结构，脚本实现了多线程并行抓取代理信息的功能，并对抓取到的代理进行了初步的验证和整理。
        """
        proxy_dict = dict()
        thread_list = list()
        self.log.info("ProxyFetch : start")

        for fetch_source in self.conf.fetchers:  # 根据配置文件中的fetchers列表,它创建并启动多个_ThreadFetcher线程 fetch_source:  freeProxy01 ...
            self.log.info("ProxyFetch - {func}: start".format(func=fetch_source))
            fetcher = getattr(ProxyFetcher, fetch_source, None)  # 获取 ProxyFetcher 类中名为 fetch_source 的方法的引用对象 如freeProxy01
            if not fetcher:
                self.log.error("ProxyFetch - {func}: class method not exists!".format(func=fetch_source))
                continue
            if not callable(fetcher):
                self.log.error("ProxyFetch - {func}: must be class method".format(func=fetch_source))
                continue
            thread_list.append(_ThreadFetcher(fetch_source, proxy_dict))

        for thread in thread_list:
            thread.setDaemon(True)
            thread.start()

        for thread in thread_list:
            thread.join()

        self.log.info("ProxyFetch - all complete!")

        for _ in proxy_dict.values():
            if DoValidator.preValidator(_.proxy):
                yield _



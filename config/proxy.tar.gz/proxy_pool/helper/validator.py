# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name:     _validators
   Description :   定义proxy验证方法
   Author :        JHao
   date:          2021/5/25
-------------------------------------------------
   Change Activity:
                   2023/03/10: 支持带用户认证的代理格式 username:password@ip:port
-------------------------------------------------
"""

import re
import requests
from requests import head
from util.six import withMetaclass
from util.singleton import Singleton
from handler.configHandler import ConfigHandler

conf = ConfigHandler()

HEADER = {
    "User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:34.0) Gecko/20100101 Firefox/34.0",
    "Accept": "*/*",
    "Connection": "keep-alive",
    "Accept-Language": "zh-CN,zh;q=0.8",
}

IP_REGEX = re.compile(r"(.*:.*@)?\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}:\d{1,5}")


class ProxyValidator(withMetaclass(Singleton)):
    pre_validator = []  # 类变量 存储预验证函数
    http_validator = []  # 类变量 存储http验证函数 httpTimeOutValidator 返回值为bool类型
    https_validator = []  # 列表中的函数都是通过装饰器addHttpsValidator注册进来的

    @classmethod
    def addPreValidator(cls, func):
        """类方法装饰器函数 添加预验证函数 到列表pre_validator中 """
        cls.pre_validator.append(func)
        # 接受一个函数作为参数&&返回了这个函数本身 所以当前类方法可以作为一个装饰器函数
        return func

    @classmethod
    def addHttpValidator(cls, func):
        """添加http验证函数 到列表中 装饰器函数 func为被装饰函数"""
        cls.http_validator.append(func)
        return func

    @classmethod
    def addHttpsValidator(cls, func):
        cls.https_validator.append(func)
        return func


@ProxyValidator.addPreValidator
def formatValidator(proxy):
    """检查代理格式是否正确"""
    return True if IP_REGEX.fullmatch(proxy) else False


@ProxyValidator.addHttpValidator
def httpTimeOutValidator(proxy):
    """http超时检测 用于检测代理是否可以发送http请求 proxy格式:ip:port的代理信息 这个函数会被添加到类变量中的列表 http_validator 中"""
    proxies = {
        "http": "http://{proxy}".format(proxy=proxy),
        "https": "https://{proxy}".format(proxy=proxy),
    }

    try:
        r = head(
            conf.httpUrl, headers=HEADER, proxies=proxies, timeout=conf.verifyTimeout
        )
        return True if r.status_code == 200 else False
    except Exception as e:
        return False


@ProxyValidator.addHttpsValidator  # 装饰器将验证函数注册到相应的验证列表中
def httpsTimeOutValidator(proxy):
    """https超时检测"""

    proxies = {
        "http": "http://{proxy}".format(proxy=proxy),
        "https": "https://{proxy}".format(proxy=proxy),
    }
    try:
        r = head(
            conf.httpsUrl,
            headers=HEADER,
            proxies=proxies,
            timeout=conf.verifyTimeout,
            verify=False,
        )
        return True if r.status_code == 200 else False
    # except requests.exceptions.RequestException as e:
    #     return False
    except Exception as e:
        return False


def customValidatorExample(proxy):
    """自定义validator函数,校验代理是否可用, 返回True/False"""
    return True

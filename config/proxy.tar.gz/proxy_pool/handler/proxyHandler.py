# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name:     ProxyHandler.py
   Description :
   Author :       JHao
   date:          2016/12/3
-------------------------------------------------
   Change Activity:
                   2016/12/03:
                   2020/05/26: 区分http和https
-------------------------------------------------
"""

from helper.proxy import Proxy
from db.dbClient import DbClient
from handler.configHandler import ConfigHandler
from handler.logHandler import LogHandler


class ProxyHandler(object):
    """Proxy CRUD operator"""

    def __init__(self):
        self.conf = ConfigHandler()
        self.db = DbClient(self.conf.dbConn)
        self.db.changeTable(self.conf.tableName)

    def get(self, https=False):
        """
        return a proxy
        Args:
            https: True/False
        Returns: 返回值有一个proxy属性为ip:port
        """
        proxy = self.db.get(https)
        # {"proxy": "1.162.12.227:80", "https": false, "fail_count": 0, "region": "中国 台湾 宜兰县 cht.com.tw", "anonymous": "", "source": "freeProxy11", "check_count": 1, "last_status": true, "last_time": "2024-07-17 19:39:40"}
        # LogHandler("proxyHandler").info(f"get proxy: {proxy}")
        return Proxy.createFromJson(proxy) if proxy else None

    def pop(self, https):
        """
        return and delete a useful proxy
        :return:
        """
        proxy = self.db.pop(https)
        if proxy:
            return Proxy.createFromJson(proxy)
        return None

    def put(self, proxy):
        """
        put proxy into use proxy
        :return:
        """
        self.db.put(proxy)

    def delete(self, proxy):
        """
        delete useful proxy
        :param proxy:
        :return:
        """
        return self.db.delete(proxy.proxy)

    def getAll(self, https=False):
        """
        get all proxy from pool as Proxy list
        :return:
        """
        proxies = self.db.getAll(https)
        return [Proxy.createFromJson(_) for _ in proxies]

    def exists(self, proxy):
        """
        check proxy exists
        :param proxy:
        :return:
        """
        return self.db.exists(proxy.proxy)

    def getCount(self):
        """
        return raw_proxy and use_proxy count
        :return:
        """
        total_use_proxy = self.db.getCount()
        return {"count": total_use_proxy}

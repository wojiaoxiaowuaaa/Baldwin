#!/usr/bin/env bash
python3 proxyPool.py server &
python3 proxyPool.py schedule
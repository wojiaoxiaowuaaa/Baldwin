# -*- coding: utf-8 -*-
# !/usr/bin/env python
"""
-------------------------------------------------
   File Name:    DbClient.py
   Description :  DB工厂类
   Author :       JHao
   date:          2016/12/2
-------------------------------------------------
   Change Activity:
                   2016/12/02:   DB工厂类
                   2020/07/03:   取消raw_proxy储存
-------------------------------------------------
"""
import logging
import os
import sys

from util.six import urlparse, withMetaclass
from util.singleton import Singleton
from handler.logHandler import LogHandler

sys.path.append(os.path.dirname(os.path.abspath(__file__)))


class DbClient(withMetaclass(Singleton)):
    """
    DbClient DB工厂类 提供get/put/update/pop/delete/exists/getAll/clean/getCount/changeTable方法
    抽象方法定义:
        get(): 随机返回一个proxy;
        put(proxy): 存入一个proxy;
        pop(): 顺序返回并删除一个proxy;
        update(proxy): 更新指定proxy信息;
        delete(proxy): 删除指定proxy;
        exists(proxy): 判断指定proxy是否存在;
        getAll(): 返回所有代理;
        clean(): 清除所有proxy信息;
        getCount(): 返回proxy统计信息;
        changeTable(name): 切换操作对象

        所有方法需要相应类去具体实现:
            ssdb: ssdbClient.py
            redis: redisClient.py
            mongodb: mongodbClient.py

    """

    def __init__(self, db_conn):
        """
        功能:构造函数,初始化数据库客户端.
        参数:db_conn 是一个数据库连接字符串.
        执行流程:
        调用 parseDbConn 方法解析数据库连接字符串.并定义 cls.db_type等一系列类属性.
        调用 __initDbClient 方法初始化数据库客户端
        """
        self.parseDbConn(db_conn)
        self.__initDbClient()

    @classmethod
    def parseDbConn(cls, db_conn):
        """功能:解析数据库连接字符串.
        参数:db_conn 是一个数据库连接字符串.
        返回:返回self  允许链式调用.
        执行流程:使用 urlparse 解析连接字符串.从解析结果中提取数据库类型、主机名、端口等信息,并存储在类变量中
        这里的scheme是 urlparse 函数解析URL后返回的对象(ParseResult对象)的一个属性.
        cls.xxx等均为类属性.构造方法中调用了当前的parseDbConn方法,所以此时cls.xxx等已经被定义"""
        db_conf = urlparse(db_conn)
        cls.db_type = db_conf.scheme.upper().strip()
        cls.db_host = db_conf.hostname
        cls.db_port = db_conf.port
        cls.db_user = db_conf.username
        cls.db_pwd = db_conf.password
        cls.db_name = db_conf.path[1:]
        return cls

    def __initDbClient(self):
        """
        功能:根据数据库类型初始化相应的数据库客户端.
        执行流程:
        根据 db_type 确定要初始化的客户端类型.
        动态导入对应的客户端模块,并创建客户端实例.
        根据传入的数据库连接字符串解析出数据库类型(例如 Redis),
        然后根据数据库类型动态加载并初始化对应的客户端类(即 redisClient.py 中的 RedisClient 类).
        """
        __type = None
        if "SSDB" == self.db_type:
            __type = "ssdbClient"
        elif "REDIS" == self.db_type:
            __type = "redisClient"
        else:
            pass
        assert __type, "type error, Not support DB type: {}".format(self.db_type)
        # 使用 Python 的 __import__ 函数动态导入对应的模块(例如 redisClient 模块).
        # 从导入的模块中获取对应的客户端类(例如 RedisClient 类),并创建该类的实例,传入必要的参数(如主机名、端口号等).
        # 将创建的实例赋值给 self.client 属性.通过这种方式,DbClient 类能够根据配置动态地支持不同类型的数据库客户端,并通过统一的接口(self.client)调用具体客户端实例的方法,实现了数据库操作的抽象和封装.
        # __import__(__type):这是Python的内置函数,用于动态地导入一个模块.在这个上下文中,__type变量包含了要导入的模块的名称,例如"redisClient".这个函数返回导入的模块对象.
        # getattr是Python的内置函数,用于从一个对象中获取一个属性.在这里,它被用来从动态导入的模块中获取一个特定的类.通过字符串格式化构造类名 RedisClient
        self.client = getattr(__import__(__type), "%sClient" % self.db_type.title())(
            host=self.db_host,
            port=self.db_port,
            username=self.db_user,
            password=self.db_pwd,
            db=self.db_name,
        )

    def get(self, https, **kwargs):
        """实际上是调用了 RedisClient 的 get 方法来从 Redis 中获取数据.
        self.client 在这里相当于 redisClient.py 中 RedisClient 类的一个实例对象 self.client <redisClient.RedisClient object at 0x107746f70>
        """
        return self.client.get(https, **kwargs)

    def put(self, key, **kwargs):
        return self.client.put(key, **kwargs)

    def update(self, key, value, **kwargs):
        return self.client.update(key, value, **kwargs)

    def delete(self, key, **kwargs):
        return self.client.delete(key, **kwargs)

    def exists(self, key, **kwargs):
        return self.client.exists(key, **kwargs)

    def pop(self, https, **kwargs):
        return self.client.pop(https, **kwargs)

    def getAll(self, https):
        return self.client.getAll(https)

    def clear(self):
        return self.client.clear()

    def changeTable(self, name):
        self.client.changeTable(name)

    def getCount(self):
        return self.client.getCount()

    def test(self):
        """测试数据库连接是否正常,检查客户端是否能够成功连接到数据库并执行基本操作"""
        # print(self.client)  # <redisClient.RedisClient object at 0x107746f70>
        return self.client.test()


# if __name__ == '__main__':
#     uri = "redis://:@127.0.0.1:6379/0"
#     db = DbClient(uri)
#     print(db.getAll(False))
